﻿using System;
using ObjCRuntime;

namespace GVLBindingLibrary
{

    [Native]
    public enum AnalysisError : long
    {
        Cancelled = 0,
        DocumentCreation = 1,
        Unknown = 2
    }

    [Native]
    public enum CameraError : long
    {
        Unknown = 0,
        NotAuthorizedToUseDevice = 1,
        NoInputDevice = 2,
        CaptureFailed = 3
    }

    [Native]
    public enum DocumentImportMethod : long
    {
        OpenWith = 0,
        Picker = 1
    }

    [Native]
    public enum DocumentPickerType : long
    {
        Gallery = 0,
        Explorer = 1
    }

    [Native]
    public enum DocumentValidationError : long
    {
        Unknown = 0,
        ExceededMaxFileSize = 1,
        ImageFormatNotValid = 2,
        FileFormatNotValid = 3,
        PdfPageLengthExceeded = 4,
        QrCodeFormatNotValid = 5
    }

    [Native]
    public enum FilePickerError : long
    {
        PhotoLibraryAccessDenied = 0,
        MaxFilesPickedCountExceeded = 1,
        MixedDocumentsUnsupported = 2
    }

    [Native]
    public enum GiniVisionImportFileTypes : long
    {
        None = 0,
        Pdf = 1,
        Pdf_and_images = 2
    }

    [Native]
    public enum GiniVisionDocumentType : long
    {
        Pdf = 0,
        Image = 1,
        Qrcode = 2
    }

    [Native]
    public enum NoticeActionType : long
    {
        ry = 0,
        ake = 1
    }

    [Native]
    public enum ReviewError : long
    {
        ReviewErrorUnknown = 0
    }

}
