﻿using System;
using CoreGraphics;
using Foundation;
using ObjCRuntime;
using UIKit;

namespace GVLBindingLibrary
{

    [Static]
    partial interface Constants
    {
        // extern double GiniVisionVersionNumber;
        [Field("GiniVisionVersionNumber", "__Internal")]
        double GiniVisionVersionNumber { get; }

        // extern const unsigned char [] GiniVisionVersionString;
        [Field("GiniVisionVersionString", "__Internal")]
        NSString GiniVisionVersionString { get; }
    }

    // @protocol AnalysisDelegate
    [Protocol(Name = "_TtP10GiniVision16AnalysisDelegate_"), Model]
    [BaseType(typeof(NSObject))]
    interface AnalysisDelegate
    {
        // @required -(void)displayErrorWithMessage:(NSString * _Nullable)message andAction:(void (^ _Nullable)(void))action;
        [Abstract]
        [Export("displayErrorWithMessage:andAction:")]
        void AndAction([NullAllowed] string message, [NullAllowed] Action action);

        // @required -(BOOL)tryDisplayNoResultsScreen __attribute__((warn_unused_result));
        [Abstract]
        [Export("tryDisplayNoResultsScreen")]
        bool TryDisplayNoResultsScreen { get; }
    }

    // @interface CustomDocumentValidationError : NSError
    [BaseType (typeof(NSError), Name = "_TtC10GiniVision29CustomDocumentValidationError")]
    interface CustomDocumentValidationError
    {
        // -(instancetype _Nonnull)initWithDomain:(NSString * _Nonnull)domain code:(NSInteger)code userInfo:(NSDictionary<NSString *,id> * _Nullable)dict __attribute__((objc_designated_initializer));
        [Export("initWithDomain:code:userInfo:")]
        [DesignatedInitializer]
        IntPtr Constructor(string domain, nint code, [NullAllowed] NSDictionary<NSString, NSObject> dict);
    }

    // @interface CustomDocumentValidationResult : NSObject
    [BaseType (typeof(NSObject), Name = "_TtC10GiniVision30CustomDocumentValidationResult")]
    [DisableDefaultCtor]
    interface CustomDocumentValidationResult
    {
        // +(instancetype _Nonnull)new __attribute__((deprecated("-init is unavailable")));
        [Static]
        [Export("new")]
        CustomDocumentValidationResult New();
    }

    // @interface GiniConfiguration : NSObject
    [BaseType (typeof(NSObject), Name = "_TtC10GiniVision17GiniConfiguration")]
    interface GiniConfiguration
    {
        // @property (nonatomic, strong) UIColor * _Nonnull backgroundColor;
        [Export("backgroundColor", ArgumentSemantic.Strong)]
        UIColor BackgroundColor { get; set; }

        // @property (copy, nonatomic) CustomDocumentValidationResult * _Nonnull (^ _Nonnull)(id<GiniVisionDocument> _Nonnull) customDocumentValidations;
        [Export("customDocumentValidations", ArgumentSemantic.Copy)]
        Func<GiniVisionDocument, CustomDocumentValidationResult> CustomDocumentValidations { get; set; }

        // @property (nonatomic, strong) GiniVisionFont * _Nonnull customFont;
        [Export("customFont", ArgumentSemantic.Strong)]
        GiniVisionFont CustomFont { get; set; }

        // @property (nonatomic) BOOL debugModeOn;
        [Export("debugModeOn")]
        bool DebugModeOn { get; set; }

        // @property (nonatomic, strong) id<GiniLogger> _Nonnull logger;
        [Export("logger", ArgumentSemantic.Strong)]
        GiniLogger Logger { get; set; }

        // @property (nonatomic) BOOL multipageEnabled;
        [Export("multipageEnabled")]
        bool MultipageEnabled { get; set; }

        // @property (nonatomic, strong) UIColor * _Nonnull navigationBarTintColor;
        [Export("navigationBarTintColor", ArgumentSemantic.Strong)]
        UIColor NavigationBarTintColor { get; set; }

        // @property (nonatomic, strong) UIColor * _Nullable navigationBarItemTintColor;
        [NullAllowed, Export("navigationBarItemTintColor", ArgumentSemantic.Strong)]
        UIColor NavigationBarItemTintColor { get; set; }

        // @property (nonatomic, strong) UIFont * _Nonnull navigationBarItemFont;
        [Export("navigationBarItemFont", ArgumentSemantic.Strong)]
        UIFont NavigationBarItemFont { get; set; }

        // @property (nonatomic, strong) UIColor * _Nonnull navigationBarTitleColor;
        [Export("navigationBarTitleColor", ArgumentSemantic.Strong)]
        UIColor NavigationBarTitleColor { get; set; }

        // @property (nonatomic, strong) UIFont * _Nonnull navigationBarTitleFont;
        [Export("navigationBarTitleFont", ArgumentSemantic.Strong)]
        UIFont NavigationBarTitleFont { get; set; }

        // @property (nonatomic, strong) UIColor * _Nonnull noticeInformationBackgroundColor;
        [Export("noticeInformationBackgroundColor", ArgumentSemantic.Strong)]
        UIColor NoticeInformationBackgroundColor { get; set; }

        // @property (nonatomic, strong) UIColor * _Nonnull noticeInformationTextColor;
        [Export("noticeInformationTextColor", ArgumentSemantic.Strong)]
        UIColor NoticeInformationTextColor { get; set; }

        // @property (nonatomic, strong) UIColor * _Nonnull noticeErrorBackgroundColor;
        [Export("noticeErrorBackgroundColor", ArgumentSemantic.Strong)]
        UIColor NoticeErrorBackgroundColor { get; set; }

        // @property (nonatomic, strong) UIColor * _Nonnull noticeErrorTextColor;
        [Export("noticeErrorTextColor", ArgumentSemantic.Strong)]
        UIColor NoticeErrorTextColor { get; set; }

        // @property (nonatomic, strong) UIFont * _Nonnull noticeFont;
        [Export("noticeFont", ArgumentSemantic.Strong)]
        UIFont NoticeFont { get; set; }

        // @property (nonatomic) BOOL openWithEnabled;
        [Export("openWithEnabled")]
        bool OpenWithEnabled { get; set; }

        // @property (copy, nonatomic) NSString * _Nonnull photoLibraryAccessDeniedMessageText;
        [Export("photoLibraryAccessDeniedMessageText")]
        string PhotoLibraryAccessDeniedMessageText { get; set; }

        // @property (nonatomic) BOOL qrCodeScanningEnabled;
        [Export("qrCodeScanningEnabled")]
        bool QrCodeScanningEnabled { get; set; }

        // @property (nonatomic) UIStatusBarStyle statusBarStyle;
        [Export("statusBarStyle", ArgumentSemantic.Assign)]
        UIStatusBarStyle StatusBarStyle { get; set; }

        // @property (copy, nonatomic) NSString * _Nonnull cameraCaptureButtonTitle;
        [Export("cameraCaptureButtonTitle")]
        string CameraCaptureButtonTitle { get; set; }

        // @property (copy, nonatomic) NSString * _Nonnull cameraNotAuthorizedText;
        [Export("cameraNotAuthorizedText")]
        string CameraNotAuthorizedText { get; set; }

        // @property (nonatomic, strong) UIFont * _Nonnull cameraNotAuthorizedTextFont;
        [Export("cameraNotAuthorizedTextFont", ArgumentSemantic.Strong)]
        UIFont CameraNotAuthorizedTextFont { get; set; }

        // @property (nonatomic, strong) UIColor * _Nonnull cameraNotAuthorizedTextColor;
        [Export("cameraNotAuthorizedTextColor", ArgumentSemantic.Strong)]
        UIColor CameraNotAuthorizedTextColor { get; set; }

        // @property (copy, nonatomic) NSString * _Nonnull cameraNotAuthorizedButtonTitle;
        [Export("cameraNotAuthorizedButtonTitle")]
        string CameraNotAuthorizedButtonTitle { get; set; }

        // @property (nonatomic, strong) UIFont * _Nonnull cameraNotAuthorizedButtonFont;
        [Export("cameraNotAuthorizedButtonFont", ArgumentSemantic.Strong)]
        UIFont CameraNotAuthorizedButtonFont { get; set; }

        // @property (nonatomic, strong) UIColor * _Nonnull cameraNotAuthorizedButtonTitleColor;
        [Export("cameraNotAuthorizedButtonTitleColor", ArgumentSemantic.Strong)]
        UIColor CameraNotAuthorizedButtonTitleColor { get; set; }

        // @property (nonatomic, strong) UIColor * _Nonnull cameraPreviewCornerGuidesColor;
        [Export("cameraPreviewCornerGuidesColor", ArgumentSemantic.Strong)]
        UIColor CameraPreviewCornerGuidesColor { get; set; }

        // @property (copy, nonatomic) NSString * _Nonnull documentValidationErrorGeneral;
        [Export("documentValidationErrorGeneral")]
        string DocumentValidationErrorGeneral { get; set; }

        // @property (copy, nonatomic) NSString * _Nonnull documentValidationErrorExcedeedFileSize;
        [Export("documentValidationErrorExcedeedFileSize")]
        string DocumentValidationErrorExcedeedFileSize { get; set; }

        // @property (copy, nonatomic) NSString * _Nonnull documentValidationErrorTooManyPages;
        [Export("documentValidationErrorTooManyPages")]
        string DocumentValidationErrorTooManyPages { get; set; }

        // @property (copy, nonatomic) NSString * _Nonnull documentValidationErrorWrongFormat;
        [Export("documentValidationErrorWrongFormat")]
        string DocumentValidationErrorWrongFormat { get; set; }

        // @property (nonatomic) enum GiniVisionImportFileTypes fileImportSupportedTypes;
        [Export("fileImportSupportedTypes", ArgumentSemantic.Assign)]
        GiniVisionImportFileTypes FileImportSupportedTypes { get; set; }

        // @property (nonatomic, strong) UIColor * _Nonnull fileImportToolTipBackgroundColor;
        [Export("fileImportToolTipBackgroundColor", ArgumentSemantic.Strong)]
        UIColor FileImportToolTipBackgroundColor { get; set; }

        // @property (nonatomic, strong) UIColor * _Nonnull fileImportToolTipTextColor;
        [Export("fileImportToolTipTextColor", ArgumentSemantic.Strong)]
        UIColor FileImportToolTipTextColor { get; set; }

        // @property (nonatomic, strong) UIColor * _Nonnull fileImportToolTipCloseButtonColor;
        [Export("fileImportToolTipCloseButtonColor", ArgumentSemantic.Strong)]
        UIColor FileImportToolTipCloseButtonColor { get; set; }

        // @property (nonatomic, strong) UIColor * _Nonnull galleryPickerItemSelectedBackgroundCheckColor;
        [Export("galleryPickerItemSelectedBackgroundCheckColor", ArgumentSemantic.Strong)]
        UIColor GalleryPickerItemSelectedBackgroundCheckColor { get; set; }

        // @property (copy, nonatomic) NSString * _Nonnull navigationBarCameraTitle;
        [Export("navigationBarCameraTitle")]
        string NavigationBarCameraTitle { get; set; }

        // @property (nonatomic, strong) UIColor * _Nonnull imagesStackIndicatorLabelTextcolor;
        [Export("imagesStackIndicatorLabelTextcolor", ArgumentSemantic.Strong)]
        UIColor ImagesStackIndicatorLabelTextcolor { get; set; }

        // @property (copy, nonatomic) NSString * _Nonnull navigationBarCameraTitleCloseButton;
        [Export("navigationBarCameraTitleCloseButton")]
        string NavigationBarCameraTitleCloseButton { get; set; }

        // @property (copy, nonatomic) NSString * _Nonnull navigationBarCameraTitleHelpButton;
        [Export("navigationBarCameraTitleHelpButton")]
        string NavigationBarCameraTitleHelpButton { get; set; }

        // @property (nonatomic, strong) UIColor * _Nonnull qrCodePopupButtonColor;
        [Export("qrCodePopupButtonColor", ArgumentSemantic.Strong)]
        UIColor QrCodePopupButtonColor { get; set; }

        // @property (nonatomic, strong) UIColor * _Nonnull qrCodePopupTextColor;
        [Export("qrCodePopupTextColor", ArgumentSemantic.Strong)]
        UIColor QrCodePopupTextColor { get; set; }

        // @property (nonatomic, strong) UIColor * _Nonnull qrCodePopupBackgroundColor;
        [Export("qrCodePopupBackgroundColor", ArgumentSemantic.Strong)]
        UIColor QrCodePopupBackgroundColor { get; set; }

        // @property (copy, nonatomic) NSString * _Nonnull navigationBarOnboardingTitle;
        [Export("navigationBarOnboardingTitle")]
        string NavigationBarOnboardingTitle { get; set; }

        // @property (copy, nonatomic) NSString * _Nonnull navigationBarOnboardingTitleContinueButton;
        [Export("navigationBarOnboardingTitleContinueButton")]
        string NavigationBarOnboardingTitleContinueButton { get; set; }

        // @property (nonatomic, strong) UIColor * _Nonnull onboardingPageIndicatorColor;
        [Export("onboardingPageIndicatorColor", ArgumentSemantic.Strong)]
        UIColor OnboardingPageIndicatorColor { get; set; }

        // @property (nonatomic, strong) UIColor * _Nonnull onboardingCurrentPageIndicatorColor;
        [Export("onboardingCurrentPageIndicatorColor", ArgumentSemantic.Strong)]
        UIColor OnboardingCurrentPageIndicatorColor { get; set; }

        // @property (nonatomic) BOOL onboardingShowAtLaunch;
        [Export("onboardingShowAtLaunch")]
        bool OnboardingShowAtLaunch { get; set; }

        // @property (nonatomic) BOOL onboardingShowAtFirstLaunch;
        [Export("onboardingShowAtFirstLaunch")]
        bool OnboardingShowAtFirstLaunch { get; set; }

        // @property (copy, nonatomic) NSString * _Nonnull onboardingFirstPageText;
        [Export("onboardingFirstPageText")]
        string OnboardingFirstPageText { get; set; }

        // @property (copy, nonatomic) NSString * _Nonnull onboardingSecondPageText;
        [Export("onboardingSecondPageText")]
        string OnboardingSecondPageText { get; set; }

        // @property (copy, nonatomic) NSString * _Nonnull onboardingThirdPageText;
        [Export("onboardingThirdPageText")]
        string OnboardingThirdPageText { get; set; }

        // @property (copy, nonatomic) NSString * _Nonnull onboardingFourthPageText;
        [Export("onboardingFourthPageText")]
        string OnboardingFourthPageText { get; set; }

        // @property (copy, nonatomic) NSString * _Nonnull onboardingFifthPageText;
        [Export("onboardingFifthPageText")]
        string OnboardingFifthPageText { get; set; }

        // @property (nonatomic, strong) UIFont * _Nonnull onboardingTextFont;
        [Export("onboardingTextFont", ArgumentSemantic.Strong)]
        UIFont OnboardingTextFont { get; set; }

        // @property (nonatomic, strong) UIColor * _Nonnull onboardingTextColor;
        [Export("onboardingTextColor", ArgumentSemantic.Strong)]
        UIColor OnboardingTextColor { get; set; }

        // @property (copy, nonatomic) NSArray<UIView *> * _Nonnull onboardingPages;
        [Export("onboardingPages", ArgumentSemantic.Copy)]
        UIView[] OnboardingPages { get; set; }

        // @property (copy, nonatomic) NSString * _Nonnull navigationBarReviewTitle;
        [Export("navigationBarReviewTitle")]
        string NavigationBarReviewTitle { get; set; }

        // @property (copy, nonatomic) NSString * _Nonnull navigationBarReviewTitleBackButton;
        [Export("navigationBarReviewTitleBackButton")]
        string NavigationBarReviewTitleBackButton { get; set; }

        // @property (copy, nonatomic) NSString * _Nonnull navigationBarReviewTitleCloseButton;
        [Export("navigationBarReviewTitleCloseButton")]
        string NavigationBarReviewTitleCloseButton { get; set; }

        // @property (copy, nonatomic) NSString * _Nonnull navigationBarReviewTitleContinueButton;
        [Export("navigationBarReviewTitleContinueButton")]
        string NavigationBarReviewTitleContinueButton { get; set; }

        // @property (copy, nonatomic) NSString * _Nonnull reviewTextTop;
        [Export("reviewTextTop")]
        string ReviewTextTop { get; set; }

        // @property (readonly, nonatomic, strong) UIFont * _Nonnull reviewTextTopFont;
        [Export("reviewTextTopFont", ArgumentSemantic.Strong)]
        UIFont ReviewTextTopFont { get; }

        // @property (copy, nonatomic) NSString * _Nonnull reviewRotateButtonTitle;
        [Export("reviewRotateButtonTitle")]
        string ReviewRotateButtonTitle { get; set; }

        // @property (copy, nonatomic) NSString * _Nonnull reviewDocumentImageTitle;
        [Export("reviewDocumentImageTitle")]
        string ReviewDocumentImageTitle { get; set; }

        // @property (nonatomic, strong) UIColor * _Nonnull reviewBottomViewBackgroundColor;
        [Export("reviewBottomViewBackgroundColor", ArgumentSemantic.Strong)]
        UIColor ReviewBottomViewBackgroundColor { get; set; }

        // @property (copy, nonatomic) NSString * _Nonnull reviewTextBottom;
        [Export("reviewTextBottom")]
        string ReviewTextBottom { get; set; }

        // @property (nonatomic, strong) UIFont * _Nonnull reviewTextBottomFont;
        [Export("reviewTextBottomFont", ArgumentSemantic.Strong)]
        UIFont ReviewTextBottomFont { get; set; }

        // @property (nonatomic, strong) UIColor * _Nonnull reviewTextBottomColor;
        [Export("reviewTextBottomColor", ArgumentSemantic.Strong)]
        UIColor ReviewTextBottomColor { get; set; }

        // @property (nonatomic, strong) UIColor * _Nonnull multipagePagesContainerAndToolBarColor;
        [Export("multipagePagesContainerAndToolBarColor", ArgumentSemantic.Strong)]
        UIColor MultipagePagesContainerAndToolBarColor { get; set; }

        // @property (nonatomic, strong) UIColor * _Nonnull multipageToolbarItemsColor;
        [Export("multipageToolbarItemsColor", ArgumentSemantic.Strong)]
        UIColor MultipageToolbarItemsColor { get; set; }

        // @property (nonatomic, strong) UIColor * _Nonnull multipagePageIndicatorColor;
        [Export("multipagePageIndicatorColor", ArgumentSemantic.Strong)]
        UIColor MultipagePageIndicatorColor { get; set; }

        // @property (nonatomic, strong) UIColor * _Nonnull multipagePageSelectedIndicatorColor;
        [Export("multipagePageSelectedIndicatorColor", ArgumentSemantic.Strong)]
        UIColor MultipagePageSelectedIndicatorColor { get; set; }

        // @property (nonatomic, strong) UIColor * _Nonnull multipagePageBackgroundColor;
        [Export("multipagePageBackgroundColor", ArgumentSemantic.Strong)]
        UIColor MultipagePageBackgroundColor { get; set; }

        // @property (nonatomic, strong) UIColor * _Nonnull multipageDraggableIconColor;
        [Export("multipageDraggableIconColor", ArgumentSemantic.Strong)]
        UIColor MultipageDraggableIconColor { get; set; }

        // @property (nonatomic, strong) UIColor * _Nonnull analysisLoadingIndicatorColor;
        [Export("analysisLoadingIndicatorColor", ArgumentSemantic.Strong)]
        UIColor AnalysisLoadingIndicatorColor { get; set; }

        // @property (copy, nonatomic) NSString * _Nonnull analysisLoadingText;
        [Export("analysisLoadingText")]
        string AnalysisLoadingText { get; set; }

        // @property (nonatomic, strong) UIColor * _Nonnull analysisPDFInformationBackgroundColor;
        [Export("analysisPDFInformationBackgroundColor", ArgumentSemantic.Strong)]
        UIColor AnalysisPDFInformationBackgroundColor { get; set; }

        // @property (nonatomic, strong) UIColor * _Nonnull analysisPDFInformationTextColor;
        [Export("analysisPDFInformationTextColor", ArgumentSemantic.Strong)]
        UIColor AnalysisPDFInformationTextColor { get; set; }

        // -(NSString * _Nonnull)analysisPDFNumberOfPagesWithPagesCount:(NSInteger)count __attribute__((warn_unused_result));
        [Export("analysisPDFNumberOfPagesWithPagesCount:")]
        string AnalysisPDFNumberOfPagesWithPagesCount(nint count);

        // @property (copy, nonatomic) NSString * _Nonnull navigationBarAnalysisTitle;
        [Export("navigationBarAnalysisTitle")]
        string NavigationBarAnalysisTitle { get; set; }

        // @property (copy, nonatomic) NSString * _Nonnull navigationBarAnalysisTitleBackButton;
        [Export("navigationBarAnalysisTitleBackButton")]
        string NavigationBarAnalysisTitleBackButton { get; set; }

        // @property (copy, nonatomic) NSString * _Nonnull navigationBarHelpMenuTitleBackToCameraButton;
        [Export("navigationBarHelpMenuTitleBackToCameraButton")]
        string NavigationBarHelpMenuTitleBackToCameraButton { get; set; }

        // @property (copy, nonatomic) NSString * _Nonnull navigationBarHelpScreenTitleBackToMenuButton;
        [Export("navigationBarHelpScreenTitleBackToMenuButton")]
        string NavigationBarHelpScreenTitleBackToMenuButton { get; set; }

        // @property (nonatomic, strong) UIColor * _Nonnull nonSupportedFormatsIconColor;
        [Export("nonSupportedFormatsIconColor", ArgumentSemantic.Strong)]
        UIColor NonSupportedFormatsIconColor { get; set; }

        // @property (nonatomic, strong) UIColor * _Nonnull supportedFormatsIconColor;
        [Export("supportedFormatsIconColor", ArgumentSemantic.Strong)]
        UIColor SupportedFormatsIconColor { get; set; }

        // @property (copy, nonatomic) NSString * _Nonnull openWithAppNameForTexts;
        [Export("openWithAppNameForTexts")]
        string OpenWithAppNameForTexts { get; set; }

        // @property (nonatomic, strong) UIColor * _Nonnull stepIndicatorColor;
        [Export("stepIndicatorColor", ArgumentSemantic.Strong)]
        UIColor StepIndicatorColor { get; set; }

        // @property (nonatomic, strong) UIColor * _Nonnull noResultsBottomButtonColor;
        [Export("noResultsBottomButtonColor", ArgumentSemantic.Strong)]
        UIColor NoResultsBottomButtonColor { get; set; }

        // @property (nonatomic, strong) UIColor * _Nonnull noResultsWarningContainerIconColor;
        [Export("noResultsWarningContainerIconColor", ArgumentSemantic.Strong)]
        UIColor NoResultsWarningContainerIconColor { get; set; }

        // @property (nonatomic) BOOL shouldShowDragAndDropTutorial;
        [Export("shouldShowDragAndDropTutorial")]
        bool ShouldShowDragAndDropTutorial { get; set; }
    }

    // @protocol GiniVisionDocument
    [Protocol(Name = "_TtP10GiniVision18GiniVisionDocument_"), Model]
    [BaseType(typeof(NSObject))]
    interface GiniVisionDocument
    {
        // @required @property (readonly, nonatomic) enum GiniVisionDocumentType type;
        [Abstract]
        [Export("type")]
        GiniVisionDocumentType Type { get; }

        // @required @property (readonly, copy, nonatomic) NSData * _Nonnull data;
        [Abstract]
        [Export("data", ArgumentSemantic.Copy)]
        NSData Data { get; }

        // @required @property (readonly, copy, nonatomic) NSString * _Nonnull id;
        [Abstract]
        [Export("id")]
        string Id { get; }

        // @required @property (readonly, nonatomic, strong) UIImage * _Nullable previewImage;
        [Abstract]
        [NullAllowed, Export("previewImage", ArgumentSemantic.Strong)]
        UIImage PreviewImage { get; }

        // @required @property (readonly, nonatomic) BOOL isReviewable;
        [Abstract]
        [Export("isReviewable")]
        bool IsReviewable { get; }

        // @required @property (readonly, nonatomic) BOOL isImported;
        [Abstract]
        [Export("isImported")]
        bool IsImported { get; }
    }

    // @protocol GiniLogger
    [Protocol(Name = "_TtP10GiniVision10GiniLogger_"), Model]
    [BaseType(typeof(NSObject))]
    interface GiniLogger
    {
        // @required -(void)logWithMessage:(NSString * _Nonnull)message;
        [Abstract]
        [Export("logWithMessage:")]
        void LogWithMessage(string message);
    }

    // @interface GiniVision : NSObject
    [BaseType (typeof(NSObject), Name = "_TtC10GiniVision10GiniVision")]
    interface GiniVision
    {
        // +(void)setConfiguration:(GiniConfiguration * _Nonnull)configuration;
        [Static]
        [Export("setConfiguration:")]
        void SetConfiguration(GiniConfiguration configuration);

        // +(UIViewController * _Nonnull)viewControllerWithDelegate:(id<GiniVisionDelegate> _Nonnull)delegate importedDocuments:(NSArray<id<GiniVisionDocument>> * _Nullable)importedDocuments __attribute__((warn_unused_result));
        [Static]
        [Export("viewControllerWithDelegate:importedDocuments:")]
        UIViewController ViewControllerWithDelegate(GiniVisionDelegate @delegate, [NullAllowed] GiniVisionDocument[] importedDocuments);

        // +(UIViewController * _Nonnull)viewControllerWithDelegate:(id<GiniVisionDelegate> _Nonnull)delegate importedDocument:(id<GiniVisionDocument> _Nullable)importedDocument __attribute__((warn_unused_result));
        [Static]
        [Export("viewControllerWithDelegate:importedDocument:")]
        UIViewController ViewControllerWithDelegate(GiniVisionDelegate @delegate, [NullAllowed] GiniVisionDocument importedDocument);

        // +(UIViewController * _Nonnull)viewControllerWithDelegate:(id<GiniVisionDelegate> _Nonnull)delegate withConfiguration:(GiniConfiguration * _Nonnull)configuration importedDocument:(id<GiniVisionDocument> _Nullable)importedDocument __attribute__((warn_unused_result));
        [Static]
        [Export("viewControllerWithDelegate:withConfiguration:importedDocument:")]
        UIViewController ViewControllerWithDelegate(GiniVisionDelegate @delegate, GiniConfiguration configuration, [NullAllowed] GiniVisionDocument importedDocument);

        // @property (readonly, copy, nonatomic, class) NSString * _Nonnull versionString;
        [Static]
        [Export("versionString")]
        string VersionString { get; }

        // +(BOOL)validate:(id<GiniVisionDocument> _Nonnull)document withConfig:(GiniConfiguration * _Nonnull)giniConfiguration error:(NSError * _Nullable * _Nullable)error;
        [Static]
        [Export("validate:withConfig:error:")]
        bool Validate(GiniVisionDocument document, GiniConfiguration giniConfiguration, [NullAllowed] out NSError error);

        // +(UIViewController * _Nonnull)viewControllerWithClient:(GiniClient * _Nonnull)client importedDocuments:(NSArray<id<GiniVisionDocument>> * _Nullable)importedDocuments configuration:(GiniConfiguration * _Nonnull)configuration resultsDelegate:(id<GiniVisionResultsDelegate> _Nonnull)resultsDelegate publicKeyPinningConfig:(NSDictionary<NSString *,id> * _Nonnull)publicKeyPinningConfig documentMetadata:(GINIDocumentMetadata * _Nullable)documentMetadata __attribute__((warn_unused_result));
        [Static]
        [Export("viewControllerWithClient:importedDocuments:configuration:resultsDelegate:publicKeyPinningConfig:documentMetadata:")]
        UIViewController ViewControllerWithClient(GiniClient client, [NullAllowed] GiniVisionDocument[] importedDocuments, GiniConfiguration configuration, GiniVisionResultsDelegate resultsDelegate, NSDictionary<NSString, NSObject> publicKeyPinningConfig, [NullAllowed] GINIDocumentMetadata documentMetadata);

        // +(UIViewController * _Nonnull)viewControllerWithClient:(GiniClient * _Nonnull)client importedDocuments:(NSArray<id<GiniVisionDocument>> * _Nullable)importedDocuments configuration:(GiniConfiguration * _Nonnull)configuration resultsDelegate:(id<GiniVisionResultsDelegate> _Nonnull)resultsDelegate documentMetadata:(GINIDocumentMetadata * _Nullable)documentMetadata __attribute__((warn_unused_result));
        [Static]
        [Export("viewControllerWithClient:importedDocuments:configuration:resultsDelegate:documentMetadata:")]
        UIViewController ViewControllerWithClient(GiniClient client, [NullAllowed] GiniVisionDocument[] importedDocuments, GiniConfiguration configuration, GiniVisionResultsDelegate resultsDelegate, [NullAllowed] GINIDocumentMetadata documentMetadata);
    }

    // @protocol GiniVisionDelegate
    [Protocol(Name = "_TtP10GiniVision18GiniVisionDelegate_"), Model]
    [BaseType(typeof(NSObject))]
    interface GiniVisionDelegate
    {
        // @required -(void)didCaptureWithDocument:(id<GiniVisionDocument> _Nonnull)document networkDelegate:(id<AnalysisDelegate,UploadDelegate> _Nonnull)networkDelegate;
        [Abstract]
        [Export("didCaptureWithDocument:networkDelegate:")]
        void DidCaptureWithDocument(GiniVisionDocument document, UploadDelegate networkDelegate);

        // @required -(void)didReviewWithDocuments:(NSArray<id<GiniVisionDocument>> * _Nonnull)documents networkDelegate:(id<AnalysisDelegate,UploadDelegate> _Nonnull)networkDelegate;
        [Abstract]
        [Export("didReviewWithDocuments:networkDelegate:")]
        void DidReviewWithDocuments(GiniVisionDocument[] documents, UploadDelegate networkDelegate);

        // @required -(void)didCancelCapturing;
        [Abstract]
        [Export("didCancelCapturing")]
        void DidCancelCapturing();

        // @required -(void)didCancelReviewFor:(id<GiniVisionDocument> _Nonnull)document;
        [Abstract]
        [Export("didCancelReviewFor:")]
        void DidCancelReviewFor(GiniVisionDocument document);

        // @required -(void)didCancelAnalysis;
        [Abstract]
        [Export("didCancelAnalysis")]
        void DidCancelAnalysis();
    }

    // @interface GiniVisionDocumentBuilder : NSObject
    [BaseType (typeof(NSObject), Name = "_TtC10GiniVision25GiniVisionDocumentBuilder")]
    [DisableDefaultCtor]
    interface GiniVisionDocumentBuilder
    {
        // +(instancetype _Nonnull)new __attribute__((deprecated("-init is unavailable")));
        [Static]
        [Export("new")]
        GiniVisionDocumentBuilder New();
    }

    // @interface GiniVisionFont : NSObject
    [BaseType (typeof(NSObject), Name = "_TtC10GiniVision14GiniVisionFont")]
    [DisableDefaultCtor]
    interface GiniVisionFont
    {
        // +(instancetype _Nonnull)new __attribute__((deprecated("-init is unavailable")));
        [Static]
        [Export("new")]
        GiniVisionFont New();
    }

    // @protocol UploadDelegate
    [BaseType(typeof(NSObject), Name = "_TtP10GiniVision14UploadDelegate_")]
    [Model]
    interface UploadDelegate
    {
        // @required -(void)uploadDidFailFor:(id<GiniVisionDocument> _Nonnull)document with:(NSError * _Nonnull)error;
        [Abstract]
        [Export("uploadDidFailFor:with:")]
        void UploadDidFailFor(GiniVisionDocument document, NSError error);

        // @required -(void)uploadDidCompleteFor:(id<GiniVisionDocument> _Nonnull)document;
        [Abstract]
        [Export("uploadDidCompleteFor:")]
        void UploadDidCompleteFor(GiniVisionDocument document);
    }

    // @interface GiniClient : NSObject
    [BaseType(typeof(NSObject), Name = "_TtC10GiniVision10GiniClient")]
    [DisableDefaultCtor]
    interface GiniClient
    {
        // -(instancetype _Nonnull)initWithClientId:(NSString * _Nonnull)clientId clientSecret:(NSString * _Nonnull)clientSecret clientEmailDomain:(NSString * _Nonnull)clientEmailDomain __attribute__((objc_designated_initializer));
        [Export("initWithClientId:clientSecret:clientEmailDomain:")]
        [DesignatedInitializer]
        IntPtr Constructor(string clientId, string clientSecret, string clientEmailDomain);

        // +(instancetype _Nonnull)new __attribute__((deprecated("-init is unavailable")));
        [Static]
        [Export("new")]
        GiniClient New();
    }

    // @protocol GiniVisionResultsDelegate
    [Protocol(Name = "_TtP10GiniVision25GiniVisionResultsDelegate_"), Model]
    [BaseType(typeof(NSObject))]
    interface GiniVisionResultsDelegate
    {
        // @required -(void)giniVisionAnalysisDidFinishWith:(NSDictionary<NSString *,GINIExtraction *> * _Nonnull)results sendFeedbackBlock:(void (^ _Nonnull)(NSDictionary<NSString *,GINIExtraction *> * _Nonnull))sendFeedbackBlock;
        [Export("giniVisionAnalysisDidFinishWith:sendFeedbackBlock:")]
        void GiniVisionAnalysisDidFinishWith(NSDictionary<NSString, GINIExtraction> results, Action<NSDictionary<NSString, GINIExtraction>> sendFeedbackBlock);

        // @required -(void)giniVisionAnalysisDidFinishWithoutResults:(BOOL)showingNoResultsScreen;
        [Export("giniVisionAnalysisDidFinishWithoutResults:")]
        void GiniVisionAnalysisDidFinishWithoutResults(bool showingNoResultsScreen);

        // @required -(void)giniVisionDidCancelAnalysis;
        [Export("giniVisionDidCancelAnalysis")]
        void GiniVisionDidCancelAnalysis();
    }

    // @interface GINIExtraction : NSObject
    [BaseType(typeof(NSObject))]
    interface GINIExtraction: INativeObject
    {
        // @property (readonly) BOOL isDirty;
        [Export("isDirty")]
        bool IsDirty { get; }

        // @property (readonly) NSString * name;
        [Export("name")]
        string Name { get; }

        // @property NSString * value;
        [Export("value")]
        string Value { get; set; }

        // @property NSString * entity;
        [Export("entity")]
        string Entity { get; set; }

        // @property NSDictionary * box;
        [Export("box", ArgumentSemantic.Assign)]
        NSDictionary Box { get; set; }

        // @property NSArray * candidates;
        [Export("candidates", ArgumentSemantic.Assign)]
        NSObject[] Candidates { get; set; }

        // +(instancetype)extractionWithName:(NSString *)name value:(NSString *)value entity:(NSString *)entity box:(NSDictionary *)box;
        [Static]
        [Export("extractionWithName:value:entity:box:")]
        GINIExtraction ExtractionWithName(string name, string value, string entity, NSDictionary box);

        // -(instancetype)initWithName:(NSString *)name value:(NSString *)value entity:(NSString *)entity box:(NSDictionary *)box;
        [Export("initWithName:value:entity:box:")]
        IntPtr Constructor(string name, string value, string entity, NSDictionary box);
    }

    // @interface GINIDocumentMetadata
    [BaseType(typeof(NSObject))]
    interface GINIDocumentMetadata
    {
        // -(instancetype)initWithBranchId:(id)branchId;
        [Export("initWithBranchId:")]
        IntPtr Constructor(NSObject branchId);

        // -(instancetype)initWithHeaders:(id)headers;
        [Export("initWithHeaders:")]
        IntPtr ConstructorHeaders(NSObject headers);

        // -(instancetype)initWithBranchId:(id)branchId additionalHeaders:(id)additionalHeaders;
        [Export("initWithBranchId:additionalHeaders:")]
        IntPtr Constructor(NSObject branchId, NSObject additionalHeaders);
    }


}
